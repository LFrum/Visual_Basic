﻿Module modMain
    Public customers As New Collection
    Public blnChange As Boolean = False

End Module
